# Relic-pocketmine

   pocketmine， 一个mcpe的服务端，php编写

一个pm的遗迹插件

本插件开源，所有注释/代码仅供参考。请勿抄袭。


地图刷新自动根据几率生成遗迹

遗迹文件放入relics文件夹


GitHub的relics文件夹里有一些赠送的遗迹文件，可直接使用


指令:

/re load

在当前地图生成一遍遗迹


/re reload

重载遗迹文件


/re pos 1/2

选择第1/2点


/re create 遗迹文件名字 生成几率 生成时y轴最高度 生成时y轴最低高度

根据选定的2个坐标生成2个点之间的地形遗迹文件
