插件基本信息
 
- 名称：PureEntitiesX
- 功能：是一款适用于PocketMine-MP的怪物AI插件，提供了诸多实体相关功能。
- 开源协议：遵循GNU General Public License开源协议，可自由分发、修改等，但无任何担保。
 
类相关说明
 
- 命名空间： revivalpmmp\pureentities\entity 。
- 基类：继承自 Creature 类，是抽象类，名为 BaseEntity 。
 
主要属性
 
-  $stayTime 、 $moveTime 等多种属性，如 $baseTarget 用于设置实体的基础目标， $movement 控制实体是否可移动， $friendly 标识是否友好， $wallcheck 控制是否进行墙体碰撞检测等。
- 还有像 $panicCounter 与恐慌相关的属性，用于记录恐慌状态等情况， $checkTargetSkipCounter 用于控制检查目标的跳过计数等。
 
主要方法
 
- 构造方法 __construct ：初始化 idlingComponent ，并根据插件配置设置如检查目标跳过的相关参数、恐慌启用情况及恐慌时长等，然后调用父类构造方法。
- 抽象方法 updateMove ：需要在具体子类中实现，用于更新实体的移动逻辑。
-  getKillExperience 方法：默认返回0，用于定义实体被击杀时掉落的经验值，子类可重写来改变经验值设定。
-  getSaveId 方法：通过反射获取类的短名称用于保存标识。
-  isMovement 、 setMovement 等系列访问器和修改器方法：用于获取和设置对应属性的值，比如获取或设置实体是否可移动、是否友好等属性。
-  initEntity 方法：初始化实体，会根据插件配置中的NBT相关设置来初始化如移动、墙体检测等属性，同时设置数据属性以及加载 idlingComponent 相关的NBT数据。
-  saveNBT 方法：根据插件配置决定是否保存NBT数据，保存如移动、墙体检测等属性以及 idlingComponent 的NBT数据。
-  spawnTo 方法：向玩家发送添加实体的数据包来使实体在玩家客户端显示，会进行相关条件判断。
-  updateMovement 方法：更新实体的移动状态，记录坐标、角度等信息到所在层级。
-  isInsideOfSolid 方法：判断实体是否在固体方块内部。
-  attack 方法：处理实体受到攻击的逻辑，包括停止闲置状态、调用父类攻击处理方法、处理击退、恐慌模式相关逻辑以及检查被驯服实体的攻击情况等。
-  entityBaseTick 方法：实体基础的每刻更新逻辑，处理如在固体中、移动时间、攻击时间、恐慌时间等相关的更新情况。
-  move 方法：处理实体移动的逻辑，进行碰撞检测、坐标更新等操作。
-  targetOption 方法：用于判断给定的生物是否可作为目标，比如怪物判断玩家是否符合可攻击目标条件等。
-  isCurrentBlockOfInterest 方法：用于检查实体当前所在方块是否是感兴趣的方块（比如羊吃草等情况），默认返回 false ，子类可重写。
-  checkAttackByTamedEntities 方法：检查当玩家被攻击时，其拥有的被驯服的实体是否会攻击当前实体等相关逻辑。
-  checkTamedMobsAttack 方法：当玩家受到攻击时，让玩家拥有的被驯服的实体（如狼）去攻击指定实体的逻辑。
-  getTamedMobs 方法：获取给定玩家拥有的所有被驯服的实体列表。
-  isCheckTargetAllowedBySkip 方法：根据跳过计数等判断是否允许检查目标。
-  isLootDropAllowed 方法：判断是否允许掉落战利品，主要依据伤害来源是否是玩家等情况。
-  panicTick 方法：用于在每刻更新中检查实体是否仍处于恐慌状态，根据恐慌计数器判断是否过期等情况。
-  isInPanic 方法：判断实体是否处于恐慌模式。
-  setInPanic 方法：设置实体进入恐慌模式，包括设置恐慌计数器、调整速度、移动时间等，并记录日志。
-  unsetInPanic 方法：取消实体的恐慌状态，重置恐慌计数器、速度，清除基础目标等，并记录日志。